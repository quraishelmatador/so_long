/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_input.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ktayabal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/20 21:55:36 by ktayabal          #+#    #+#             */
/*   Updated: 2025/02/20 22:04:06 by ktayabal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

char	*find_map_path(char *path)
{
	return (my_ft_strjoin("maps/", path));
}

int	check_open_map(char *path)
{
	int			fd;
	char		*map_path;

	if (check_args_and_name(path) == 0)
		return (0);
	map_path = find_map_path(path);
	fd = open(map_path, O_RDONLY);
	free (map_path);
	if (fd < 0)
	{
		perror("int check_map(char *path): Error opening map\n");
		return (0);
	}
	close(fd);
	return (1);
}

int	check_args_and_name(char *path)
{
	int	l;

	l = ft_strlen(path) - 1;
	if (path[l] != 'r' || path[l - 1] != 'e' || \
		path[l - 2] != 'b' || path[l - 3] != '.')
	{
		ft_perror("ERROR: Map file must be *.ber !\n");
		return (0);
	}
	return (1);
}

int	check_input(char *path)
{
	if (!check_args_and_name(path))
		return (0);
	if (!check_open_map(path))
		return (0);
	return (1);
}
