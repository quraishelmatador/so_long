/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ktayabal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/20 21:55:45 by ktayabal          #+#    #+#             */
/*   Updated: 2025/03/01 11:33:09 by ktayabal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	main(int argc, char **argv)
{
	if (argc != 2)
		return (ft_perror("Error\nInvalid number of arguments\n"), (1));
	if (!check_map(argv[1]))
		return (1);
	t_game	*game = malloc(sizeof(t_game));
	if (!game)
		return (1);

	(void)argc;
	game->mlx = mlx_init();
	if (!game->mlx)
		return (free(game), (1));
	init_map(argv[1], game);
	init_game(game);
	display_map(game);
	mlx_hook(game->win, 17, 0, ft_close, game);
	mlx_key_hook(game->win, handle_keypress, game);
	mlx_loop(game->mlx);

}