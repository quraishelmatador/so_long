/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ktayabal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/20 21:55:45 by ktayabal          #+#    #+#             */
/*   Updated: 2025/02/20 21:55:47 by ktayabal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

// int	main(int argc, char **argv)
// {
// 	check_open_map(argc ,argv[1]);
// }

int	main(int argc, char **argv)
{
	t_map	map;
	t_point	player;

	(void)argc;
	map.map = convert_to_matrix(argv[1]);
	map.rows = get_rows(map.map);
	map.cols = get_columns(map.map);
	player = find_player(map.map);
	floodFillStart(map, player.x, player.y);
	for (int i = 0; i < map.rows; i++)
		printf("%s\n", map.map[i]);
	return (0);
}
