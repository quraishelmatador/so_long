/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ktayabal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/28 22:16:09 by ktayabal          #+#    #+#             */
/*   Updated: 2025/02/28 22:16:10 by ktayabal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	move_up(t_game *game)
{
	int	new_y;
	int	new_x;

	new_y = game->player.pos.y - 1;
	new_x = game->player.pos.x;
	if (new_y < 0 || game->map.map[new_y][new_x] == '1')
		return ;
	if (game->map.map[new_y][new_x] == 'C')
		game->map.collec_count--;
	if (game->map.map[new_y][new_x] == 'E')
	{
		if (game->map.collec_count == 0)
			ft_close(game);
	}
	if (game->map.map[game->player.pos.y][game->player.pos.x] == 'P')
		game->map.map[game->player.pos.y][game->player.pos.x] = '0';
	game->player.pos.y = new_y;
	if (game->map.map[new_y][new_x] != 'E')
		game->map.map[new_y][new_x] = 'P';
	game->moves++;
	ft_putstr_fd("Moves: ", 1);
	ft_putnbr_fd(game->moves, 1);
	ft_putchar_fd('\n', 1);
	display_map(game);
}

void	move_down(t_game *game)
{
	int	new_y;
	int	new_x;

	new_y = game->player.pos.y + 1;
	new_x = game->player.pos.x;
	if (new_y >= game->map.rows || game->map.map[new_y][new_x] == '1')
		return ;
	if (game->map.map[new_y][new_x] == 'C')
		game->map.collec_count--;
	if (game->map.map[new_y][new_x] == 'E')
	{
		if (game->map.collec_count == 0)
			ft_close(game);
	}
	if (game->map.map[game->player.pos.y][game->player.pos.x] == 'P')
		game->map.map[game->player.pos.y][game->player.pos.x] = '0';
	game->player.pos.y = new_y;
	if (game->map.map[new_y][new_x] != 'E')
		game->map.map[new_y][new_x] = 'P';
	game->moves++;
	ft_putstr_fd("Moves: ", 1);
	ft_putnbr_fd(game->moves, 1);
	ft_putchar_fd('\n', 1);
	display_map(game);
}

void	move_left(t_game *game)
{
	int	new_y;
	int	new_x;

	new_y = game->player.pos.y;
	new_x = game->player.pos.x - 1;
	if (new_x < 0 || game->map.map[new_y][new_x] == '1')
		return ;
	if (game->map.map[new_y][new_x] == 'C')
		game->map.collec_count--;
	if (game->map.map[new_y][new_x] == 'E')
	{
		if (game->map.collec_count == 0)
			ft_close(game);
	}
	if (game->map.map[game->player.pos.y][game->player.pos.x] == 'P')
		game->map.map[game->player.pos.y][game->player.pos.x] = '0';
	game->player.pos.x = new_x;
	if (game->map.map[new_y][new_x] != 'E')
		game->map.map[new_y][new_x] = 'P';
	game->moves++;
	ft_putstr_fd("Moves: ", 1);
	ft_putnbr_fd(game->moves, 1);
	ft_putchar_fd('\n', 1);
	display_map(game);
}

void	move_right(t_game *game)
{
	int	new_y;
	int	new_x;

	new_y = game->player.pos.y;
	new_x = game->player.pos.x + 1;
	if (new_x >= game->map.cols || game->map.map[new_y][new_x] == '1')
		return ;
	if (game->map.map[new_y][new_x] == 'C')
		game->map.collec_count--;
	if (game->map.map[new_y][new_x] == 'E')
	{
		if (game->map.collec_count == 0)
			ft_close(game);
	}
	if (game->map.map[game->player.pos.y][game->player.pos.x] == 'P')
		game->map.map[game->player.pos.y][game->player.pos.x] = '0';
	game->player.pos.x = new_x;
	if (game->map.map[new_y][new_x] != 'E')
		game->map.map[new_y][new_x] = 'P';
	game->moves++;
	ft_putstr_fd("Moves: ", 1);
	ft_putnbr_fd(game->moves, 1);
	ft_putchar_fd('\n', 1);
	display_map(game);
	display_map(game);
}

int	handle_keypress(int keycode, t_game *game)
{
	if (keycode == XK_Escape)
		ft_close(game);
	else if (keycode == XK_w)
		move_up(game);
	else if (keycode == XK_s)
		move_down(game);
	else if (keycode == XK_a)
		move_left(game);
	else if (keycode == XK_d)
		move_right(game);
	return (0);
}
