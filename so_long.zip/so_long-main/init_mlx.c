/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_mlx.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ktayabal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 17:21:55 by ktayabal          #+#    #+#             */
/*   Updated: 2025/02/25 17:21:57 by ktayabal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	init_map(char *path, t_game *game)
{
	game->map.map = convert_to_matrix(path);
	game->map.rows = get_rows(game->map.map);
	game->map.cols = get_columns(game->map.map);
	game->map.collec_count = check_collectibles(game->map.map);
	game->player.pos = find_player(game->map.map);
	game->moves = 0;
	game->x = 0;
	game->y = 0;
}

void	init_game(t_game *game)
{
	game->win = mlx_new_window(game->mlx, game->map.cols * TILE_SIZE, \
		game->map.rows * TILE_SIZE, "so_long");
	game->player.path = "textures/player.xpm";
	game->player.ptr = mlx_xpm_file_to_image(game->mlx, game->player.path, \
		&game->player.width, &game->player.height);
	game->exit.path = "textures/exit.xpm";
	game->exit.ptr = mlx_xpm_file_to_image(game->mlx, game->exit.path, \
		&game->exit.width, &game->exit.height);
	game->collectible.path = "textures/collectible.xpm";
	game->collectible.ptr = mlx_xpm_file_to_image \
		(game->mlx, game->collectible.path, \
		&game->collectible.width, &game->collectible.height);
	game->wall.path = "textures/wall.xpm";
	game->wall.ptr = mlx_xpm_file_to_image(game->mlx, game->wall.path, \
		&game->wall.width, &game->wall.height);
	game->background.path = "textures/background.xpm";
	game->background.ptr = mlx_xpm_file_to_image \
	(game->mlx, game->background.path, \
		&game->background.width, &game->background.height);
}

void	display_map(t_game *game)
{
	game->y = 0;
	while (game->y < game->map.rows)
	{
		game->x = 0;
		while (game->x < game->map.cols)
		{
			mlx_put_image_to_window(game->mlx, game->win, \
				game->background.ptr, game->x * TILE_SIZE, game->y * TILE_SIZE);
			if (game->map.map[game->y][game->x] == '1')
				mlx_put_image_to_window(game->mlx, game->win,
					game->wall.ptr, game->x * TILE_SIZE, game->y * TILE_SIZE);
			else if (game->map.map[game->y][game->x] == 'P')
				mlx_put_image_to_window(game->mlx, game->win,
					game->player.ptr, game->x * TILE_SIZE, game->y * TILE_SIZE);
			else if (game->map.map[game->y][game->x] == 'C')
				mlx_put_image_to_window(game->mlx, game->win,
					game->collectible.ptr, game->x * TILE_SIZE,
					game->y * TILE_SIZE);
			else if (game->map.map[game->y][game->x] == 'E')
				mlx_put_image_to_window(game->mlx, game->win,
					game->exit.ptr, game->x * TILE_SIZE, game->y * TILE_SIZE);
			game->x++;
		}
		game->y++;
	}
}

int	ft_close(t_game *game)
{
	mlx_destroy_image(game->mlx, game->player.ptr);
	mlx_destroy_image(game->mlx, game->exit.ptr);
	mlx_destroy_image(game->mlx, game->collectible.ptr);
	mlx_destroy_image(game->mlx, game->wall.ptr);
	mlx_destroy_image(game->mlx, game->background.ptr);
	mlx_destroy_window(game->mlx, game->win);
	mlx_destroy_display(game->mlx);
	free(game->mlx);
	free_matrix(game->map.map);
	free(game);
	exit(0);
	return (0);
}
