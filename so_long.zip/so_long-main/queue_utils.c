/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   queue_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ktayabal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 10:18:06 by ktayabal          #+#    #+#             */
/*   Updated: 2025/02/25 10:18:07 by ktayabal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	init_point_queue(t_point_queue *q)
{
	q->head = NULL;
	q->tail = NULL;
}

int	enqueue_point(t_point_queue *q, t_point pt)
{
	t_point_list	*newnode;

	newnode = malloc(sizeof(t_point_list));
	if (newnode == NULL)
		return (0);
	newnode->point = pt;
	newnode->next = NULL;
	if (q->tail != NULL)
		q->tail->next = newnode;
	q->tail = newnode;
	if (q->head == NULL)
		q->head = newnode;
	return (1);
}

t_point	dequeue_point(t_point_queue *q)
{
	t_point pt;
	t_point_list	*tmp;

	pt.x = -1;
	pt.y = -1;
	if (q->head == NULL)
		return (pt);
	tmp = q->head;
	pt = tmp->point;
	q->head = q->head->next;
	if (q->head == NULL)
		q->tail = NULL;
	free(tmp);
	return (pt);
}

void	enqueue_neighbors(t_point_queue *queue, int x, int y)
{
	t_point	neighbor;

	neighbor.x = x + 1;
	neighbor.y = y;
	enqueue_point(queue, neighbor);
	neighbor.x = x - 1;
	neighbor.y = y;
	enqueue_point(queue, neighbor);
	neighbor.x = x;
	neighbor.y = y + 1;
	enqueue_point(queue, neighbor);
	neighbor.x = x;
	neighbor.y = y - 1;
	enqueue_point(queue, neighbor);
}

void	flood_fill(char **map, t_point player, int rows, int cols)
{
	t_point_queue	queue;
	t_point	start;
	t_point	current;
	int	x;
	int	y;

	init_point_queue(&queue);
	start.x = player.x;
	start.y = player.y;
	enqueue_point(&queue, start);
	while (queue.head != NULL)
	{
		current = dequeue_point(&queue);
		x = current.x;
		y = current.y;
		if (x < 0 || y < 0 || x >= cols || y >= rows)
			continue ;
		if (map[y][x] == '1' || map[y][x] == 'V')
			continue ;
		map[y][x] = 'V';
		enqueue_neighbors(&queue, x, y);
	}
}
