/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checkpath.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ktayabal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/22 09:50:48 by ktayabal          #+#    #+#             */
/*   Updated: 2025/02/22 09:50:50 by ktayabal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	floodFill(t_map map, int x, int y)
{
	// First this
	if (x < 0 || x >= map.rows || y < 0 || y >= map.cols)
	{
		return ;
	}
	// If the current position is not a free spot...
	if (map.map[x][y] == '1' || map.map[x][y] == 'V')
	{
		return ;
	}
	map.map[x][y] = 'V';
	floodFill(map, x, y + 1);
	floodFill(map, x, y - 1);
	floodFill(map, x + 1, y);
	floodFill(map, x - 1, y);
}

void	floodFillStart(t_map map, int x, int y)
{
	// Temporarily clear the starting spot
	if (map.map[x][y] == 'P')
	{
		map.map[x][y] = '0';
	}
	floodFill(map, x, y);
}

int	check_map(char *path)
{
	t_map map;
	t_point player;

	if (!check_open_map(path))
		return (0);
	map.map = convert_to_matrix(path);
	map.rows = get_rows(map.map);
	map.cols = get_columns(map.map);
	player = find_player(map.map);
	if (!check_player(map.map) || !check_exit(map.map)
		|| !check_collectibles(map.map) || !check_rectangular(map.map)
		|| !check_chars_in_map(map.map))
		return (free_matrix(map.map), (0));
	if (!check_walls(map.map))
		return (free_matrix(map.map), (0));
	return (free_matrix(map.map), (1));
}