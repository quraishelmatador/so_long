/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checkpath.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ktayabal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/22 09:50:48 by ktayabal          #+#    #+#             */
/*   Updated: 2025/02/22 09:50:50 by ktayabal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	is_valid_path(char **map)
{
	int	rows;
	int	cols;
	int	x;
	int	y;

	rows = get_rows(map);
	cols = get_rows(map);
	y = 0;
	while (y < rows)
	{
		x = 0;
		while (x < cols)
		{
			if (map[y][x] == 'C' || map[y][x] == 'E')
			{
				ft_perror("Error:\nValid path not found !\n");
				return (0);
			}
			x++;
		}
		y++;
	}
	return (1);
}

int	check_map(char *path)
{
	t_map	map;
	t_point	player;

	if (!check_open_map(path))
		return (0);
	map.map = convert_to_matrix(path);
	map.rows = get_rows(map.map);
	map.cols = get_columns(map.map);
	player = find_player(map.map);
	if (!check_player(map.map) || !check_exit(map.map)
		|| !check_collectibles(map.map) || !check_rectangular(map.map)
		|| !check_chars_in_map(map.map))
		return (free_matrix(map.map), (0));
	if (!check_walls(map.map))
		return (free_matrix(map.map), (0));
	flood_fill(map.map, player, map.rows, map.cols);
	if (!is_valid_path(map.map))
		return (free_matrix(map.map), (0));
	return (free_matrix(map.map), (1));
}
