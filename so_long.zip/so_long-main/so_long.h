#ifndef SO_LONG_H
# define SO_LONG_H

# include "include/Libft/libft.h"
# include "include/get_next_line/get_next_line.h"
# include "minilibx-linux/mlx.h"

# include <fcntl.h>
# include <stdio.h>
#include <X11/keysym.h>


# define TILE_SIZE 50

typedef struct s_point
{
	int	x;
	int	y;
}	t_point;

typedef struct s_point_list
{
	t_point			point;
	struct s_point_list	*next;
}	t_point_list;

typedef struct s_point_queue
{
	t_point_list	*head;
	t_point_list	*tail;
}	t_point_queue;


typedef struct s_map
{
	int	rows;
	int	cols;
	char	**map;
	int	collec_count;
}	t_map;

typedef struct s_img
{
	char	*path;
	void	*ptr;
	int	width;
	int	height;
	t_point	pos;
}	t_img;

typedef struct s_game
{
	void	*mlx;
	void	*win;
	int	moves;
	t_img	player;
	t_img	exit;
	t_img	collectible;
	t_img	wall;
	t_img	background;
	t_map	map;
	int	x;
	int	y;
}	t_game;


// check_input.c
int	check_open_map(char *path);
int	check_args_and_name(char *path);
char	*find_map_path(char *path);
int	check_input(char *path);

// map.c
char	*convert_to_str(char *path);
char	**convert_to_matrix(char *path);
void	free_matrix(char **matrix);
char	**map_dup(char **map);
t_point	find_player(char **map);

// check_chars_in_map.c
int	check_player(char **map);
int	check_exit(char **map);
int	check_collectibles(char **map);
int	check_rectangular(char **map);
int	check_chars_in_map(char **map);

// check_map.c
int	get_rows(char **map);
int	get_columns(char **map);
int	checkwalls_first_last_rows(char **map);
int	checkwalls_left_right_columns(char **map);
int	check_walls(char **map);

// checkpath.c
int	is_valid_path(char **map);
int	check_map(char *path);

//queue_utils.c
void	init_point_queue(t_point_queue *q);
int	enqueue_point(t_point_queue *q, t_point pt);
t_point	dequeue_point(t_point_queue *q);
void	enqueue_neighbors(t_point_queue *queue, int x, int y);
void	flood_fill(char **map, t_point player, int rows, int cols);

// init_mlx.c
void	init_map(char *path, t_game *game);
void	init_game(t_game *game);
void	display_map(t_game *game);
int	handle_keypress(int keycode, t_game *game);
int	ft_close(t_game *game);

// move.c
void	move_up(t_game *game);
void	move_down(t_game *game);
void	move_right(t_game *game);
void	move_left(t_game *game);

#endif